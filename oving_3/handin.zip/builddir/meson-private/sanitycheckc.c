int main(void) { int class=0; return class; }
