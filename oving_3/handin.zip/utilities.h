

#pragma once


// oppgave 5 
// --------------------------
// 5 b)
int randomWithLimits(int min, int max);


// --------------------------